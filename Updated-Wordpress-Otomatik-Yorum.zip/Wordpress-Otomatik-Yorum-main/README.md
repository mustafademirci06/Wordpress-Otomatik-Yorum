
# YorumBot-2.0 Güncellemesi Yayınlandı

05.09.2024 tarihi itibariyle V2 sürümü yayınlanmıştır. Kullanmaya devam edebilirsiniz.

## Neler Değişti?
- Tüm sistem baştan kodlandı.
- Eski klasik görünümün yanı sıra bir de profesyonel görünüm eklendi.
  - Bu görünümde istatistik görmek ve denetimli yorum yapmak mümkün hale getirildi.
- Bazı sistemlerde yaşanan tablo adı bulma sorunu düzeltildi.
- Config dosyasından yayın ve görünüm değiştirme gibi denetimleri yapma imkanı getirildi.

## Kurulum Rehberi
1. **Dosyaları Yükleyin**:
   - İndirilen dosyaları `wp-content/plugins` klasörüne yükleyin.

2. **Eklentiyi Etkinleştirin**:
   - WordPress yönetici paneline gidin.
   - "Eklentiler" sekmesine tıklayın.
   - "YorumBot-2.0" eklentisini etkinleştirin.

3. **Ayarları Yapılandırın**:
   - `config.php` dosyasını düzenleyerek bot ayarlarınızı yapılandırın.
   - Anahtar kelimeler, zamanlama ve dil seçeneklerini buradan ayarlayabilirsiniz.

4. **Test Edin**:
   - WordPress üzerinde bir yazı oluşturarak botun çalışmasını test edin.

## Ekran Görüntüleri
![image](https://github.com/user-attachments/assets/b8b0e7e9-c3e7-4495-b47b-d1f713f6973c)
![image](https://github.com/user-attachments/assets/801e656b-4baf-4edb-8c25-0ffdcea51410)
![image](https://github.com/user-attachments/assets/12f3fa94-3f30-4781-b543-ea752225f90b)

---

**Yaratıcı**: Mustafa Demirci
